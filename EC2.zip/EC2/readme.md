terraform destroy -var 'traffic_distribution=green' -var 'enable_blue_env=false' -var 'enable_green_env=true' -auto-approve

terraform apply -var 'traffic_distribution=green' -var 'enable_blue_env=false' -var 'enable_green_env=true' -auto-approve

terraform apply -var 'traffic_distribution=split' -var 'enable_green_env=true' -auto-approve

terraform apply -var 'traffic_distribution=blue-90' -var 'enable_green_env=true' -auto-approve

--Execute this command to run and load website

for i in `seq 1 1000`; do curl $(terraform output -raw lb_dns_name); done


https://developer.hashicorp.com/terraform/tutorials/aws/blue-green-canary-tests-deployments

https://faun.pub/aws-ecs-blue-green-deployment-setup-using-terraform-b56bb4f656ea

https://github.com/vinycoolguy2015/awslambda/tree/master/terraform_ecs_bluegreen
